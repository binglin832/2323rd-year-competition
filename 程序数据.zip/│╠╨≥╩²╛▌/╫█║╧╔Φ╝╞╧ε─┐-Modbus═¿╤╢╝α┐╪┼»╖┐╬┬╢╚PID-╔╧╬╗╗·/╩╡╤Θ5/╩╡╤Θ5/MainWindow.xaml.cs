﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.IO.Ports;//后面加的  串口要用
using System.Runtime.InteropServices;//后面加的   共用体要用
using System.Windows.Shapes;
using System.Windows.Threading;
using LiveCharts;
using LiveCharts.Wpf;
using System.Threading;

[StructLayout(LayoutKind.Explicit)]
public struct IpAddress
{
    // FieldOffset 表示偏移的位置（以字节为单位）
    // sizeof(float) = 4, sizeof(byte) = 1
    [FieldOffset(0)] public float Address;
    [FieldOffset(0)] public byte Byte1;
    [FieldOffset(1)] public byte Byte2;
    [FieldOffset(2)] public byte Byte3;
    [FieldOffset(3)] public byte Byte4;

    public IpAddress(float address) : this()
    {
        // 给 Address 赋值时，所有成员的值都会自动被修改
        Address = address;
    }

    public override string ToString() => $"{Byte1}.{Byte2}.{Byte3}.{Byte4}";
}


namespace 实验5
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private static SerialPort port = new SerialPort("COM1");
        DispatcherTimer timer1 = new DispatcherTimer();
        DispatcherTimer timer2 = new DispatcherTimer();
        DispatcherTimer timer3 = new DispatcherTimer();
        DispatcherTimer timer4 = new DispatcherTimer();
        IpAddress[] data = new IpAddress[8];
        bool f10;//10功能吗超时检测用
        bool f04;//04功能吗超时检测用
        float y_alarm, r_alarm;
        float temp;
        float set_temp;
        float temp1;
        float set_temp1;
        //曲线
        int time = 0;//记录时间
        public SeriesCollection seriesCollection { get; set; }
       
        public List<string> Labels { get; set; }
        static int x_num = 600;    //x轴时间长度坐标更改
        
        private double[] temps = new double[x_num];

        public MainWindow()
        { 
            
              InitializeComponent();
            string[] ports = System.IO.Ports.SerialPort.GetPortNames();//获取电脑上可用串口号
            port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);//串口接收函数
            combobox1.Items.Clear();
            foreach (var i in ports)
            {
                combobox1.Items.Add(i);
            }
            combobox1.Text = ports[0];
            button5.IsEnabled = false;

            combobox2.Items.Add("2400");
            combobox2.Items.Add("4800");
            combobox2.Items.Add("9600");
            combobox2.Items.Add("14400");
            combobox2.Items.Add("19200");
            combobox2.Items.Add("38400");
            combobox2.Items.Add("76800");
            combobox2.Items.Add("115200");
            combobox2.Text = "115200";


            timer1.Interval = TimeSpan.FromMilliseconds(1000);//1000 ms定时时间
            timer1.Tick += timer1_Tick;
            timer2.Interval = TimeSpan.FromMilliseconds(400);//400ms
            timer2.Tick += timer2_Tick;
            timer3.Interval = TimeSpan.FromMilliseconds(400);//400ms
            timer3.Tick += timer3_Tick;
            y_alarm = Convert.ToSingle(textbox8.Text);//字符串转浮点型
            r_alarm = Convert.ToSingle(textbox9.Text);//字符串转浮点型

            //下面这一部分是曲线控件相关的
            //实例化一条折线图
            LineSeries line1 = new LineSeries();
            LineSeries line2 = new LineSeries();
            LineSeries line3 = new LineSeries();
            LineSeries line4 = new LineSeries();
            //设置折线的标题
            line1.Title = "Temp";
            line2.Title = "Set";
            line1.Title = "Temp1";
            line2.Title = "Set1";
            //设置折线的形式
            line1.LineSmoothness = 0;
            line2.LineSmoothness = 0;
            line3.LineSmoothness = 0;
            line4.LineSmoothness = 0;
            //折线图的无点样式
            line1.PointGeometry = null;
            line2.PointGeometry = null;
            line3.PointGeometry = null;
            line4.PointGeometry = null;
            //添加横坐标
            Labels = new List<string> ();

            for (int i = 0; i < x_num; i++)//
            {
                temps[i] = 0;
                Labels.Add(0.ToString());//刚开始的横轴坐标都设为0
            }
            //添加绘图的数据
            line1.Values = new ChartValues<double>(temps);
            line2.Values = new ChartValues<double>(temps);
            line3.Values = new ChartValues<double>(temps);
            line4.Values = new ChartValues<double>(temps);
            seriesCollection = new SeriesCollection();
            seriesCollection.Add(line1);
            seriesCollection.Add(line2);
            seriesCollection.Add(line3);
            seriesCollection.Add(line4);
            DataContext = this;
            this.sl.Series = seriesCollection;
            slx.Labels = Labels;

        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            string str = "";
            string str1 = "";
            byte[] arr1 = new byte[8] { 0x07, 0x04, 0x00, 0x00, 0x00, 0x02, 0x71, 0xAD };

            for (int i = 0; i < 8; i++)
            {
                str1 = Convert.ToString(arr1[i], 16);
                if (str1.Length < 2) str1 = "0" + str1;
                str += str1 + " ";
            }
            textbox1.AppendText("发送数据" + str);//对话框追加显示数据
            textbox1.AppendText(Environment.NewLine);
            textbox1.ScrollToEnd();
            port.Write(arr1, 0, 8);//循环发送

            //更新横坐标时间
            //Labels.Add(time++.ToString());
            //Labels.RemoveAt(0);
            Labels.Add(DateTime.Now.ToString("HH:mm:ss"));
            Labels.RemoveAt(0);
            //更新纵坐标数据
            seriesCollection[1].Values.Add((double)set_temp);
            seriesCollection[1].Values.RemoveAt(0);
            seriesCollection[0].Values.Add((double)temp);
            seriesCollection[0].Values.RemoveAt(0);
            seriesCollection[3].Values.Add((double)set_temp1);
            seriesCollection[3].Values.RemoveAt(0);
            seriesCollection[2].Values.Add((double)temp1);
            seriesCollection[2].Values.RemoveAt(0);

            timer3.Start();
            f04 = false;
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (f10 == false)//通讯失败
            {
                textbox1.AppendText("10功能码未在规定时间内接收数据或数据错误");//对话框追加显示数据
                textbox1.AppendText(Environment.NewLine);
                textbox1.ScrollToEnd();
            }
            timer2.Stop();
        }
        private void timer3_Tick(object sender, EventArgs e)
        {
            if (f04 == false)//通讯失败
            {
                textbox1.AppendText("04功能码未在规定时间内接收数据或数据错误");//对话框追加显示数据
                textbox1.AppendText(Environment.NewLine);
                textbox1.ScrollToEnd();
            }
            timer3.Stop();
        }
        //private void timer4_Tick(object sender, EventArgs e)
        //{
        //    Double _trend = Double.Parse(a);
        //}
        private UInt16 check_crc(byte[] fu, int g)
        {

            UInt16 crc = 0xffff;
            int h = 0;
            int i;
            int g1;
            for (g1 = g; g1 > 0; g1--)
            {

                crc = (UInt16)(crc ^ fu[h]);
                for (i = 8; i > 0; i--)
                {
                    if ((crc & 1) == 1)
                    {
                        crc >>= 1;
                        crc ^= 0xa001;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
                h++;
            }
            return crc;
        }
        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)//串口接收数据
        {
            bool error = false;//数据错误的标志位
            int len = port.BytesToRead;//获取可以读取的字节数
            byte[] buff = new byte[len];//创建缓存数据数组
            port.Read(buff, 0, len);//把数据读取到buff数组
            /*
             * 在串口接收函数上对其他控件的修改会报错
             * 由于串口接收函数运行时是另外一个线程，不是界面显示的线程，两个线程之间数据不能直接访问
             * 通过委托的方法实现数据访问
             */
            Dispatcher.Invoke(new Action(() => {//委托操作GUI控件的部分

                string str = "";//在消息框显示要用
                string str1;//在消息框显示要用
                for (int i = 0; i < len; i++)
                {
                    str1 = Convert.ToString(buff[i], 16);//16
                    if (str1.Length < 2) str1 = "0" + str1;
                    str += (str1 + " ");
                }

                textbox1.AppendText("接收数据" + str);//对话框追加显示数据
                textbox1.AppendText(Environment.NewLine);
                textbox1.ScrollToEnd();

                if (len > 2)//防止接收1个字节数据，访问数组下标越界程序报错
                {
                    if (buff[0] == 0x07)//设备地址
                    {
                        if (buff[1] == 0x10)//功能码
                        {
                            if (len == 8)//接收的数据长度为8
                            {
                                //由于报文格式确定，故每次计算的CRC也是固定的，故直接写出CRC值避免无意义的重复计算
                                byte[] arr = new byte[8] { 0x07, 0x10, 0x00, 0x00, 0x00, 0x11, 0x00, 0x63 };//接收报文
                                for (int i = 0; i < 8; i++)//判 ，断是否与上面的数据一样
                                {
                                    if (buff[i] != arr[i])//如果有不一样的
                                    {
                                        error = true;//错误标志位为true
                                    }
                                }
                                if (error == false)//错误标志位为false   接收报文正常
                                {
                                    f10 = true;//10功能码正常接收，定时器超时检测要用，如果不正常则为false，定时时间到检测不是true，则认为通讯错误
                                }
                            }
                            else//接收的数据长度不是8
                            {
                                error = true;//错误标志位为true
                            }

                        }
                        if (buff[1] == 0x04)//04功能码
                        {
                            if (len == 21)//数据长度13字节  21
                            {
                                if (buff[2] == 0x10)//8个字节的数据 16
                                {
                                    UInt16 crc;
                                    IpAddress[] data = new IpAddress[4];//长度为2的共用体数组
                                    for (int i = 0; i < 4; i++)
                                    {
                                        data[i].Byte1 = buff[(i * 4) + 3];
                                        data[i].Byte2 = buff[(i * 4) + 4];
                                        data[i].Byte3 = buff[(i * 4) + 5];
                                        data[i].Byte4 = buff[(i * 4) + 6];


                                    }
                                    byte[] arr = new byte[2];//长度为2的数组 用于存放计算的CRC

                                    crc = check_crc(buff, 19);
                                    arr[0] = (byte)(crc & 0xff);
                                    arr[1] = (byte)(crc / 256);
                                    if ((arr[1] == buff[20]) && (arr[0] == buff[19]))//CRC值进行对比
                                    {

                                        暖房1PID.Text = data[0].Address.ToString();//PID计算值对应的文本框显示

                                        暖房1温度.Text = data[1].Address.ToString();//当前温度值对应的文本框显示
                                        
                                        暖房2PID.Text = data[2].Address.ToString();//PID计算值对应的文本框显示

                                        暖房2温度.Text = data[3].Address.ToString();//当前温度值对应的文本框显示
                                        temp = data[0].Address;
                                        temp1 = data[2].Address;
                                        if (temp > y_alarm)//当前温度超过设置的黄色报警值
                                        {
                                            textbox7.Text = "黄色报警";
                                        }
                                        if (temp > r_alarm)//当前温度超过设置的红色报警值
                                        {
                                            textbox7.Text = "红色报警";
                                        }
                                        f04 = true;//04功能码数据接收正常

                                        //下面这一部分为曲线控件相关

                                        ////更新横坐标时间
                                        //Labels.Add(time++.ToString());
                                        //Labels.RemoveAt(0);
                                        //更新纵坐标数据
                                        //seriesCollection[0].Values.Add((double)temp);
                                        //seriesCollection[0].Values.RemoveAt(0);
                                        

                                    }
                                }
                            }
                            else
                            {
                                error = true;
                            }
                        }
                        if (error == true)
                        {
                            textbox1.AppendText("接收到错误数据");//对话框追加显示数据
                            textbox1.AppendText(Environment.NewLine);
                            textbox1.ScrollToEnd();
                        }
                    }

                }
            }));
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            string[] ports = System.IO.Ports.SerialPort.GetPortNames();//获取电脑上可用串口号
            combobox1.Items.Clear();
            foreach (var i in ports)
            {
                combobox1.Items.Add(i);
            }
            combobox1.Text = ports[0];


        }

        private void button4_Click(object sender, RoutedEventArgs e)//打开串口按钮
        {

            port.PortName = combobox1.Text;//串口号
            port.BaudRate = Convert.ToInt32(combobox2.Text);//波特率
            port.DataBits = 8;
            port.Parity = Parity.None;
            port.StopBits = StopBits.One;
            button4.IsEnabled = false;
            button5.IsEnabled = true;
            port.Open();

        }

        private void button5_Click(object sender, RoutedEventArgs e)//关闭串口按钮
        {

            button4.IsEnabled = true;
            button5.IsEnabled = false;
            port.Close();

        }

        private void button7_Click(object sender, RoutedEventArgs e)//启动按钮
        {
            if (port.IsOpen)
            {
                button7.IsEnabled = false;
                button8.IsEnabled = true;
                
                timer1.Start();
                senddata_10();
            }
            else
            {
                MessageBox.Show("未打开串口");
            }
        }
        public void senddata_10()//10功能码发送
        {
            byte[] arr2 = new byte[43];
            UInt16 crcdtat;

            string str1;
            byte[] arr1 = new byte[7] { 0x07, 0x10, 0x00, 0x00, 0x00, 0x11, 0x22 };

            byte[] arry = new byte[32];
            byte[] arr3 = new byte[2] { 0, 0 };
            if (port.IsOpen)//打开串口
            {
                string str = "";
                data[0].Address = Convert.ToSingle(textbox3.Text);//字符串转浮点型
                data[1].Address = Convert.ToSingle(textbox4.Text);//字符串转浮点型
                data[2].Address = Convert.ToSingle(textbox5.Text);//字符串转浮点型
                data[3].Address = Convert.ToSingle(textbox6.Text);//字符串转浮点型
                data[4].Address = Convert.ToSingle(textbox3_Copy.Text);//字符串转浮点型
                data[5].Address = Convert.ToSingle(textbox4_Copy.Text);//字符串转浮点型
                data[6].Address = Convert.ToSingle(textbox5_Copy.Text);//字符串转浮点型
                data[7].Address = Convert.ToSingle(textbox6_Copy.Text);//字符串转浮点型
                set_temp = data[0].Address;//设定温度值
                set_temp1 = data[4].Address;
                for (int i = 0; i < 8; i++)
                {
                    arry[i * 4 + 0] = data[i].Byte1;
                    arry[i * 4 + 1] = data[i].Byte2;
                    arry[i * 4 + 2] = data[i].Byte3;
                    arry[i * 4 + 3] = data[i].Byte4;
                }

                for (int i = 0; i < 7; i++)
                {
                    arr2[i] = arr1[i];
                }
                for (int i = 0; i < 32; i++)
                {
                    arr2[i + 7] = arry[i];
                }
                if (!button7.IsEnabled)
                {
                    arr3[1] += 1;
                }
                arr2[39] = arr3[0];
                arr2[40] = arr3[1];

                crcdtat = check_crc(arr2, 41);
                arr2[41] = (byte)(crcdtat % 256);
                arr2[42] = (byte)(crcdtat / 256);

                /*对话框显示发送的数据*/
                for (int i = 0; i < 43; i++)
                {
                    str1 = Convert.ToString(arr2[i], 16);
                    if (str1.Length < 2) str1 = "0" + str1;
                    str += str1 + " ";
                }
                textbox1.AppendText("发送数据" + str);//对话框追加显示数据
                textbox1.AppendText(Environment.NewLine);
                textbox1.ScrollToEnd();
                port.Write(arr2, 0, 43);//循环发送
                timer2.Start();
                f10 = false;
            }
            else
            {
                MessageBox.Show("未打开串口");
            }
        }
        private void button10_Click(object sender, RoutedEventArgs e)//4个浮点数数据的发送按钮
        {
            senddata_10();
        }

        private void button8_Click(object sender, RoutedEventArgs e)//停止按按钮
        {
            button7.IsEnabled = true;
            button8.IsEnabled = false;
            timer1.Stop();
            timer2.Stop();
            timer3.Stop();
            senddata_10();
        }

        private void button2_Click(object sender, RoutedEventArgs e)//清除接收按钮
        {
            textbox1.Text = "";
        }

        //private void button3_Click(object sender, RoutedEventArgs e)//清除发送按钮
        //{
        //    textbox2.Text = "";
        //}

        private void button9_Click(object sender, RoutedEventArgs e)
        {
            y_alarm = Convert.ToSingle(textbox8.Text);//字符串转浮点型
            r_alarm = Convert.ToSingle(textbox9.Text);//字符串转浮点型
        }

        private void textbox11_Copy1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            /*
            * 将填入的十六进制数据发送，16进制数据格式直接2个0-F的代表一个字节 
            * 一个字节数据例如FF   
            * 二个字节数据例如3031  
            */
            byte[] Data = new byte[100];
            if (port.IsOpen && textbox2.Text != "")//串口打开,内容不为空
            {
                if (textbox2.Text.Length % 2 == 0)
                {
                    for (int i = 0; i < textbox2.Text.Length / 2; i++)
                    {
                        Data[i] = Convert.ToByte(textbox2.Text.Substring(i * 2, 2), 16);
                        port.Write(Data, i, 1);//循环发送
                    }

                    textbox1.AppendText("发送数据" + textbox2.Text);
                    textbox1.AppendText(Environment.NewLine);
                    textbox1.ScrollToEnd();
                }
                else
                {
                    MessageBox.Show("数据格式错误，数量应为偶数");
                }

            }
            else
            {
                if (!port.IsOpen)
                {
                    MessageBox.Show("未打开串口");
                }
                if (textbox2.Text == "")
                {
                    MessageBox.Show("内容为空");
                }
            }
        }

    }
}

 
