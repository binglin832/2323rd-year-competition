#include "pid.h"

int pwm_pid(float pid_pv,
	          float pid_sv 	,
	          float pid_p,
	          float pid_ti,
	          float pid_td	
            )
{ 
    	float pid_es,pid_kp,pid_ki,pid_kd; 
    	float pwm;
	    int pan;
    	float pid_ei=0;
    	float pid_ed=0;
    	float pv_last=0;
    	int time=5;
    	if(pid_pv<0)
    		pwm=5000;
    	else
    {
    	  pid_es=pid_sv-pid_pv;
    	  pid_kp=pid_p*pid_es; 
    	  pid_ed=(pid_es-pv_last)/time;
    		pid_kd=pid_p*(pid_td*pid_ed); 
       	pv_last=pid_es;
    	if((pid_es<=2&&pid_es>=0)||(pid_es>=-2&&pid_es<=0))
    	   {
    		      pid_ei+=pid_es;
    		      pid_ki=pid_p*(pid_ei/pid_ti);
    		      pan=1;              //�Ƿ����΢�ַ����־
    	   }
    	   else
    	       {
    		       pan=0;               //�Ƿ����΢�ַ����־
    	       }
    	        pwm=pid_kp+pid_ki*pan+pid_kd;
			 			 if(pwm>5000&&pwm>=0)
							 pwm=5000;
						 else 
							 if(pwm<0&&pwm<-5000)
								 pwm=-5000;
							 else pwm=pwm;
    }
  return pwm;
}

